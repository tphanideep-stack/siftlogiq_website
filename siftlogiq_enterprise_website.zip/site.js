const steps = ["Detect", "Explain", "Recommend", "Approve", "Execute", "Verify"];
const stories = [
  ["AI token leak", "$4,200/mo", "Prompt cache miss and long output cap"],
  ["Dataflow over-provisioned", "$2,400/mo", "Workers fixed high after migration"],
  ["SaaS renewal waste", "$1,100/mo", "Inactive seats before renewal"]
];

function renderDemo() {
  const root = document.querySelector("[data-demo]");
  if (!root) return;
  let index = 0;
  function tick() {
    const step = steps[index % steps.length];
    root.querySelectorAll("[data-flow]").forEach((el, i) => el.classList.toggle("active", i <= index % steps.length));
    const story = stories[index % stories.length];
    root.querySelector("[data-demo-title]").textContent = `${step}: ${story[0]}`;
    root.querySelector("[data-demo-copy]").textContent = `${story[2]}. Siftlogiq keeps writes approval-gated and records rollback evidence.`;
    root.querySelector("[data-demo-impact]").textContent = story[1];
    index += 1;
  }
  tick();
  setInterval(tick, 1800);
}

renderDemo();
