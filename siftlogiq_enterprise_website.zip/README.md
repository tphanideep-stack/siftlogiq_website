# Siftlogiq Enterprise Website

Multi-page enterprise website plus embedded MVP tool.

Pages:

- `index.html`: homepage and buyer journey.
- `platform.html`: platform capabilities.
- `solutions.html`: use cases.
- `security.html`: trust and governance model.
- `pricing.html`: pilot-first packaging.
- `demo.html`: animated product tour.
- `trial.html`: guided trial page with embedded tool.
- `app.html`: copied MVP tool.

Open `index.html` in a browser to start.
