# Siftlogiq Website Deployment Guide

## Recommended: Cloudflare Pages

1. Push every file in this folder to the website repository.
2. In Cloudflare, open Workers & Pages, then create a Pages project from Git.
3. Use these build settings:
   - Framework preset: None
   - Build command: leave empty
   - Build output directory: `/`
4. Add the custom domains:
   - `siftlogiq.com`
   - `www.siftlogiq.com`
5. Cloudflare will handle SSL automatically.

## Package Contents

- `index.html` - final static homepage
- `_headers` - security and cache headers for Cloudflare Pages
- `_redirects` - canonical domain redirects and SPA-style fallback
- `robots.txt` - search engine rules
- `sitemap.xml` - sitemap for the main landing sections

## Final QA Notes

- Navigation anchors resolve to existing sections.
- Privacy Policy and Terms of Service sections are included.
- The direct competitor comparison has been replaced with a generic FinOps evaluation guide.
- Pricing includes USD/INR and monthly/annual display toggles.
- The demo now covers dashboard, anomaly detection, code review, Kubernetes, SaaS, data + AI, and board reporting.
- The free audit form is now a generic technology spend audit form.
- Form submissions are wired for Google Sheets + thank-you email through `google-apps-script.gs`.
- Competitive and savings copy has been softened to avoid brittle or legally risky claims.
- Contact details used on the site:
  - `sales@siftlogiq.com`
  - `hello@siftlogiq.com`
  - `+91-7993800567`

## Google Sheets Form Backend

The static site cannot write directly to Google Sheets or send email without exposing credentials. Use the included Apps Script backend.

1. Open the target Sheet:
   `https://docs.google.com/spreadsheets/d/1Mc4462ZsmQB2gFTXOfvKHXPbHuSP2ytluM0wxxCIKnM/edit`
2. Go to Extensions -> Apps Script.
3. Paste the contents of `google-apps-script.gs`.
4. Click Deploy -> New deployment -> Web app.
5. Set:
   - Execute as: Me
   - Who has access: Anyone
6. Authorize the script.
7. Copy the Web app URL.
8. In `index.html`, replace:
   `PASTE_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE`
   with the copied Web app URL.

After this, every form submission will append to the `Audit Requests` sheet tab and send a thank-you email to the submitted work email.

Important: after any Apps Script code change, open Deploy -> Manage deployments, edit the web app deployment, choose New version, then deploy again. Reusing an old deployment version is the most common reason the form appears to submit but no Sheet row or email appears.

Use the public Web App URL that looks like:
`https://script.google.com/macros/s/AKfycb.../exec`

Avoid the domain-scoped URL that looks like:
`https://script.google.com/a/macros/yourdomain.com/s/AKfycb.../exec`

The domain-scoped URL can redirect and drop form data from a static `index.html` page.

## Apps Script Debug Checklist

1. In Apps Script, select the `testSetup` function and click Run.
2. Authorize permissions for both Google Sheets and Gmail/Mail.
3. Confirm the Sheet has an `Audit Requests` tab with a `Siftlogiq QA` test row.
4. Confirm `sales@siftlogiq.com` receives the test email.
5. If a website submission fails, check the `Audit Errors` tab in the same Sheet.
6. Make sure the deployed URL ends in `/exec`, not `/dev`.
7. Make sure the web app access is `Anyone`, not only your organization or only yourself.
8. If `Audit Errors` says missing required fields and both Post data and Parameters are blank, replace the `/a/macros/...` URL with the public `/macros/s/.../exec` URL and redeploy the latest Apps Script version.

## Launch Checklist

- Replace `https://siftlogiq.com/og.png` with the final Open Graph image before broad sharing.
- Deploy the Apps Script backend and paste the Web app URL into `index.html`.
- Test one real submission before pointing paid traffic to the page.
- Review pricing and service commitments with legal before paid traffic campaigns.
