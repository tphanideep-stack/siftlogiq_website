const SHEET_ID = '1Mc4462ZsmQB2gFTXOfvKHXPbHuSP2ytluM0wxxCIKnM';
const SHEET_NAME = 'Audit Requests';
const SALES_EMAIL = 'sales@siftlogiq.com';

function doPost(e) {
  try {
    const payload = parsePayload_(e);
    return handleSubmission_(payload);
  } catch (err) {
    logError_(err, e);
    return json_({ ok: false, error: err.message });
  }
}

function doGet(e) {
  try {
    if (e && e.parameter && e.parameter.firstName) {
      return handleSubmission_(e.parameter);
    }
    return json_({ ok: true, service: 'Siftlogiq audit form' });
  } catch (err) {
    logError_(err, e);
    return json_({ ok: false, error: err.message });
  }
}

function handleSubmission_(payload) {
  validatePayload_(payload);

  const sheet = getOrCreateSheet_();
  ensureHeaders_(sheet);

  sheet.appendRow([
    new Date(),
    payload.firstName || '',
    payload.lastName || '',
    payload.company || '',
    payload.email || '',
    payload.phone || '',
    payload.primarySpendArea || '',
    payload.monthlyTechSpend || '',
    payload.reviewFocus || '',
    payload.source || 'siftlogiq.com',
    payload.submittedAt || ''
  ]);

  sendUserThanks_(payload);
  sendSalesNotification_(payload);

  return json_({ ok: true });
}

function parsePayload_(e) {
  if (e && e.parameter && Object.keys(e.parameter).length) {
    return e.parameter;
  }
  if (e && e.postData && e.postData.contents) {
    const contents = e.postData.contents;
    try {
      return JSON.parse(contents);
    } catch (err) {
      return parseUrlEncoded_(contents);
    }
  }
  return {};
}

function parseUrlEncoded_(contents) {
  return contents.split('&').reduce(function (acc, part) {
    const pieces = part.split('=');
    const key = decodeURIComponent((pieces[0] || '').replace(/\+/g, ' '));
    const value = decodeURIComponent((pieces.slice(1).join('=') || '').replace(/\+/g, ' '));
    if (key) acc[key] = value;
    return acc;
  }, {});
}

function validatePayload_(payload) {
  const required = ['firstName', 'lastName', 'company', 'email', 'phone', 'primarySpendArea', 'monthlyTechSpend'];
  const missing = required.filter((key) => !payload[key]);
  if (missing.length) throw new Error('Missing required fields: ' + missing.join(', '));
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email)) throw new Error('Invalid email');
}

function getOrCreateSheet_() {
  const spreadsheet = SpreadsheetApp.openById(SHEET_ID);
  return spreadsheet.getSheetByName(SHEET_NAME) || spreadsheet.insertSheet(SHEET_NAME);
}

function ensureHeaders_(sheet) {
  const headers = [
    'Timestamp',
    'First name',
    'Last name',
    'Company',
    'Work email',
    'Phone / WhatsApp',
    'Primary spend area',
    'Monthly technology spend',
    'Review focus',
    'Source',
    'Submitted at'
  ];

  const current = sheet.getRange(1, 1, 1, headers.length).getValues()[0];
  if (current.join('') === '') {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
  }
}

function sendUserThanks_(payload) {
  const name = payload.firstName || 'there';
  const subject = 'Thanks for booking your Siftlogiq audit';
  const body =
`Hi ${name},

Thanks for requesting a free Siftlogiq technology spend audit.

We received your details:

Company: ${payload.company}
Primary spend area: ${payload.primarySpendArea}
Monthly technology spend: ${payload.monthlyTechSpend}

Our team will review the request and reach out within 4 working hours with next steps.

Siftlogiq helps teams review cloud, Kubernetes, SaaS, AI, data, code, and DevOps spend from one place.

Regards,
Siftlogiq Team
sales@siftlogiq.com`;

  MailApp.sendEmail({
    to: payload.email,
    subject,
    body,
    name: 'Siftlogiq'
  });
}

function sendSalesNotification_(payload) {
  const subject = 'New Siftlogiq audit request - ' + payload.company;
  const body =
`New Siftlogiq audit request

Name: ${payload.firstName} ${payload.lastName}
Company: ${payload.company}
Work email: ${payload.email}
Phone / WhatsApp: ${payload.phone}
Primary spend area: ${payload.primarySpendArea}
Monthly technology spend: ${payload.monthlyTechSpend}
Review focus: ${payload.reviewFocus || 'Not provided'}
Source: ${payload.source || 'siftlogiq.com'}
Submitted at: ${payload.submittedAt || ''}

Google Sheet:
https://docs.google.com/spreadsheets/d/${SHEET_ID}/edit`;

  MailApp.sendEmail({
    to: SALES_EMAIL,
    subject,
    body,
    name: 'Siftlogiq Website'
  });
}

function logError_(err, e) {
  try {
    const spreadsheet = SpreadsheetApp.openById(SHEET_ID);
    const sheet = spreadsheet.getSheetByName('Audit Errors') || spreadsheet.insertSheet('Audit Errors');
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(['Timestamp', 'Error', 'Post data', 'Parameters']);
      sheet.setFrozenRows(1);
    }
    sheet.appendRow([
      new Date(),
      err && err.message ? err.message : String(err),
      e && e.postData ? e.postData.contents : '',
      e && e.parameter ? JSON.stringify(e.parameter) : ''
    ]);
  } catch (ignored) {
    // Avoid masking the original error response.
  }
}

function testSetup() {
  const payload = {
    firstName: 'Test',
    lastName: 'Lead',
    company: 'Siftlogiq QA',
    email: SALES_EMAIL,
    phone: '+91-7993800567',
    primarySpendArea: 'Full technology stack',
    monthlyTechSpend: 'Test submission',
    reviewFocus: 'Apps Script setup test',
    source: 'manual testSetup',
    submittedAt: new Date().toISOString()
  };

  validatePayload_(payload);
  const sheet = getOrCreateSheet_();
  ensureHeaders_(sheet);
  sheet.appendRow([
    new Date(),
    payload.firstName,
    payload.lastName,
    payload.company,
    payload.email,
    payload.phone,
    payload.primarySpendArea,
    payload.monthlyTechSpend,
    payload.reviewFocus,
    payload.source,
    payload.submittedAt
  ]);
  sendUserThanks_(payload);
  sendSalesNotification_(payload);
}

function json_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
